# Changelog

* 1.3 - 2014-01-12
    * NEW: Blog logos and author images must be at least 100px in height and width, but do not need to be 1:1 (closes #6)
* 1.2.1 - 2013-12-14
    * Added Font Awesome icons
    * Changed pagination links to use Font Awesome Icons
    * Added "Read Article" links at the bottom of article previews
* 1.2 - 2013-11-10
    * Added LESS-generated CSS
    * Changed default link colors
* 1.1.2 - 2013-11-10
    * Added `text-align: center` to `#blog-logo` (closes [#3](https://github.com/sethlilly/Vapor/issues/3))
* 1.1.1 - 2013-10-30
   * Add cyrillic support for font set
* 1.1 - 2013-10-28
   * Added support for Disqus (thanks [@frdmn](https://github.com/frdmn))
* 1.0 - 2013-10-18
